#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>

using namespace std;

class Student
{
public:
    int id;
    char name[50];
    int age;
    char course[50];
    float marks;

    void input()
    {
        cout << "\nEnter Student ID: ";
        cin >> id;

        cin.ignore();

        cout << "Enter Name: ";
        cin.getline(name, 50);

        cout << "Enter Age: ";
        cin >> age;

        cin.ignore();

        cout << "Enter Course: ";
        cin.getline(course, 50);

        cout << "Enter Marks: ";
        cin >> marks;
    }

    void display()
    {
        cout << left
             << setw(10) << id
             << setw(20) << name
             << setw(10) << age
             << setw(20) << course
             << setw(10) << marks
             << endl;
    }
};

void addStudent()
{
    Student s;

    ofstream file("students.dat", ios::binary | ios::app);

    if (!file)
    {
        cout << "Error opening file!\n";
        return;
    }

    s.input();

    file.write(reinterpret_cast<char*>(&s), sizeof(s));

    file.close();

    cout << "\nStudent record added successfully!\n";
}

void displayStudents()
{
    Student s;

    ifstream file("students.dat", ios::binary);

    if (!file)
    {
        cout << "\nNo records found.\n";
        return;
    }

    cout << "\n==============================================================\n";
    cout << left
         << setw(10) << "ID"
         << setw(20) << "Name"
         << setw(10) << "Age"
         << setw(20) << "Course"
         << setw(10) << "Marks" << endl;
    cout << "==============================================================\n";

    while (file.read(reinterpret_cast<char*>(&s), sizeof(s)))
    {
        s.display();
    }

    file.close();
}

void searchStudent()
{
    Student s;
    int searchId;
    bool found = false;

    cout << "\nEnter Student ID to search: ";
    cin >> searchId;

    ifstream file("students.dat", ios::binary);

    while (file.read(reinterpret_cast<char*>(&s), sizeof(s)))
    {
        if (s.id == searchId)
        {
            cout << "\nStudent Found:\n\n";

            cout << left
                 << setw(10) << "ID"
                 << setw(20) << "Name"
                 << setw(10) << "Age"
                 << setw(20) << "Course"
                 << setw(10) << "Marks" << endl;

            s.display();

            found = true;
            break;
        }
    }

    file.close();

    if (!found)
    {
        cout << "\nStudent record not found.\n";
    }
}

void updateStudent()
{
    Student s;
    int updateId;
    bool found = false;

    cout << "\nEnter Student ID to update: ";
    cin >> updateId;

    fstream file("students.dat", ios::binary | ios::in | ios::out);

    if (!file)
    {
        cout << "File not found!\n";
        return;
    }

    while (file.read(reinterpret_cast<char*>(&s), sizeof(s)))
    {
        if (s.id == updateId)
        {
            cout << "\nCurrent Record:\n";
            s.display();

            cout << "\nEnter New Details:\n";
            s.input();

            long pos = file.tellg() - static_cast<long>(sizeof(s));

            file.seekp(pos);

            file.write(reinterpret_cast<char*>(&s), sizeof(s));

            found = true;

            cout << "\nRecord updated successfully!\n";
            break;
        }
    }

    file.close();

    if (!found)
    {
        cout << "\nStudent record not found.\n";
    }
}

void deleteStudent()
{
    Student s;
    int deleteId;
    bool found = false;

    cout << "\nEnter Student ID to delete: ";
    cin >> deleteId;

    ifstream infile("students.dat", ios::binary);

    ofstream outfile("temp.dat", ios::binary);

    while (infile.read(reinterpret_cast<char*>(&s), sizeof(s)))
    {
        if (s.id == deleteId)
        {
            found = true;
        }
        else
        {
            outfile.write(reinterpret_cast<char*>(&s), sizeof(s));
        }
    }

    infile.close();
    outfile.close();

    remove("students.dat");
    rename("temp.dat", "students.dat");

    if (found)
    {
        cout << "\nStudent record deleted successfully!\n";
    }
    else
    {
        cout << "\nStudent record not found.\n";
    }
}

void menu()
{
    int choice;

    do
    {
        cout << "\n====================================\n";
        cout << "   STUDENT MANAGEMENT SYSTEM\n";
        cout << "====================================\n";
        cout << "1. Add Student\n";
        cout << "2. Display Students\n";
        cout << "3. Search Student\n";
        cout << "4. Update Student\n";
        cout << "5. Delete Student\n";
        cout << "6. Exit\n";
        cout << "====================================\n";
        cout << "Enter Choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            addStudent();
            break;

        case 2:
            displayStudents();
            break;

        case 3:
            searchStudent();
            break;

        case 4:
            updateStudent();
            break;

        case 5:
            deleteStudent();
            break;

        case 6:
            cout << "\nExiting Program...\n";
            break;

        default:
            cout << "\nInvalid Choice!\n";
        }

    } while (choice != 6);
}

int main()
{
    menu();
    return 0;
}